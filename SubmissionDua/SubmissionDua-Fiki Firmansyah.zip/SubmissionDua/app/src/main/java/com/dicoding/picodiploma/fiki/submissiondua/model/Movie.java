package com.dicoding.picodiploma.fiki.submissiondua.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {
    private int imageMovie;
    private String titleMovie;
    private String description;
    private String tahun;

    public Movie() {
    }

    public Movie(int imageMovie, String titleMovie, String description, String tahun) {
        this.imageMovie = imageMovie;
        this.titleMovie = titleMovie;
        this.description = description;
        this.tahun = tahun;
    }

    protected Movie(Parcel in) {
        imageMovie = in.readInt();
        titleMovie = in.readString();
        description = in.readString();
        tahun = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public int getImageMovie() {
        return imageMovie;
    }

    public void setImageMovie(int imageMovie) {
        this.imageMovie = imageMovie;
    }

    public String getTitleMovie() {
        return titleMovie;
    }

    public void setTitleMovie(String titleMovie) {
        this.titleMovie = titleMovie;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTahun() {
        return tahun;
    }

    public void setTahun(String tahun) {
        this.tahun = tahun;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(imageMovie);
        dest.writeString(titleMovie);
        dest.writeString(description);
        dest.writeString(tahun);
    }
}
