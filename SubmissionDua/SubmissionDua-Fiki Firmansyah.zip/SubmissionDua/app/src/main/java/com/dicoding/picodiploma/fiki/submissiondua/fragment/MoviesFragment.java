package com.dicoding.picodiploma.fiki.submissiondua.fragment;


import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.dicoding.picodiploma.fiki.submissiondua.model.Movie;
import com.dicoding.picodiploma.fiki.submissiondua.R;
import com.dicoding.picodiploma.fiki.submissiondua.activity.DetailMovieActivity;
import com.dicoding.picodiploma.fiki.submissiondua.adapter.CardviewMovieAdapter;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MoviesFragment extends Fragment implements View.OnClickListener{
    private RecyclerView rvMovie;
    private String[] dataMovieTitle;
    private String[] dataDescription;
    private TypedArray dataPhoto;
    private String[] dataTahun;
    private ArrayList<Movie> movies;
    Button btnDetail;
    private CardviewMovieAdapter adapter;

    View view;
    final static String KEY = "KEY";
    public MoviesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_movies, container, false);
        //adapter = new CardviewMovieAdapter(movies,getContext());
        rvMovie = view.findViewById(R.id.rv_movies);
        prepare();
        addItem();
        showRecyclerCardView();
        adapter = new CardviewMovieAdapter(movies, getContext());

//        adapter.setOnItemClickListener(new CardviewMovieAdapter.OnItemClickListener() {
//            @Override
//            public void onClick(int position) {
//                final Movie movie = movies.get(position);
//
//                Intent i = new Intent(getActivity(), DetailMovieActivity.class);
//                i.putExtra("informasi", adapter.get(position));
//                startActivity(i);
//            }
//        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
    private void showRecyclerCardView(){
        rvMovie.setLayoutManager(new LinearLayoutManager(getActivity()));
        CardviewMovieAdapter adapter = new CardviewMovieAdapter(movies,getActivity());
        rvMovie.setAdapter(adapter);
    }
    private void prepare() {
        dataMovieTitle = getResources().getStringArray(R.array.data_movie_name);
        dataTahun = getResources().getStringArray(R.array.tahun_movie);
        dataDescription = getResources().getStringArray(R.array.data_desc_movie);
        dataPhoto = getResources().obtainTypedArray(R.array.data_photo_movie);
    }
    private void addItem(){
        movies = new ArrayList<>();
        for (int i=0; i < dataMovieTitle.length; i++){
            Movie movie = new Movie();
            movie.setImageMovie(dataPhoto.getResourceId(i, -1));
            movie.setTitleMovie(dataMovieTitle[i]);
            movie.setTahun(dataTahun[i]);
            movie.setDescription(String.format(dataDescription[i]));
            movies.add(movie);
        }
    }
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.card_view){

        }
    }
}
